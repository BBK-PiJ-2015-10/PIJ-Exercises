public interface LinkedList<T>
{
	public void add(T n);
	public T remove();
}